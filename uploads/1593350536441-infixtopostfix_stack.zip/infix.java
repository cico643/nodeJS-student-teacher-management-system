/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;

/**
 *
 * @author b404-3
 */
public class infix {
    
    
    
    
    
    public static void main(String[] args) {
         String str = "(10+20)*(30+40)/(50+60)";
         if (!hatakontrol(str)) {
             System.out.println("Parantez Hatası");
        }
         
         else{
         postfix p = new postfix(100);
        int sayac=0;
        char kiyas;
        
        String Pos="";
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i)=='+' || str.charAt(i)=='-' || str.charAt(i)=='/'  || str.charAt(i)=='*') {
                sayac++;
                p.push(str.charAt(i));
            }
           
           
            else if (str.charAt(i)==')') {
                for (int j = 0; j < sayac; j++) {
                    kiyas=p.pop();
                    Pos = Pos.concat(Character.toString(kiyas));
                }
                sayac=0;
               
                
                
            }
            else if (str.charAt(i)=='(') {
                continue;
            }
            else{
                Pos = Pos.concat(Character.toString(str.charAt(i)));
            }
        }
        System.out.println(Pos);
         }
        
       
    }
    
    public static boolean hatakontrol(String str)
    {
        stackchar s = new stackchar(100);
        char kiyas;
       
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i)=='{' || str.charAt(i)=='[' || str.charAt(i)=='(') {
                s.push(str.charAt(i));
            }
            
            else if (str.charAt(i)=='}' ) {
               kiyas=s.pop();
                if (kiyas!='{') {
                    
                    return false;
                }
            }
            
            else if (str.charAt(i)==']') {
                kiyas=s.pop();
                if (kiyas!='[') {
                    return false;
                }
            }
           
            else if (str.charAt(i)==')') {
                kiyas=s.pop();
                if (kiyas!='(') {
                    return false;
                }
            }
        }
        if (!s.isEmpty()) {
            return false;
            
        }
        return true;
    }
    
}
